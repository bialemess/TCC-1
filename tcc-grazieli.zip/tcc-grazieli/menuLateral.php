<?php
echo '<nav class="menu-lateral">
<ul>
    <li class="item-menu">
        <a href="index.php">
            <span class="icon"><i class="bi bi-house"></i></span>
            <span class="txt-link">HOME</span>
            </a>
</li>
<li class="item-menu">
        <a href="pedidos.php">
            <span class="icon"><i class="bi bi-columns-gap"></i></span>
            <span class="txt-link">PEDIDOS</span>
            </a>
</li>
<li class="item-menu">
        <a href="cadastro.php">
            <span class="icon"><i class="bi bi-journal-plus"></i></span>
            <span class="txt-link">CADASTRO</span>
            </a>
</li>
<li class="item-menu">
        <a href="relatorio.php">
            <span class="icon"><i class="bi bi-file-text"></i></span>
            <span class="txt-link">RELATÓRIO</span>
            </a>
</li>
<li class="item-menu">
        <a href="estoque.php">
            <span class="icon"><i class="bi bi-box"></i></span>
            <span class="txt-link">ESTOQUE</span>
            </a>
</li>
</ul>
</nav>'



?>
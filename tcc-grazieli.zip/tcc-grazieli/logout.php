<?php

include('login.php');
session_destroy();
?>